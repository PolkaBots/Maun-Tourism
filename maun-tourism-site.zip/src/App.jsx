
export default function MaunTourism() {
  return (
    <div className="bg-white text-gray-800 font-sans">
      <header className="bg-green-900 text-white p-6">
        <h1 className="text-3xl font-bold">Explore Maun, Botswana</h1>
        <p className="text-lg">Your gateway to the Okavango Delta</p>
      </header>

      <section className="p-6">
        <h2 className="text-2xl font-semibold mb-4">Top Hotels & Lodges</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <HotelCard name="Thamalakane River Lodge" desc="Luxury riverside lodge with sunset views and wildlife nearby." />
          <HotelCard name="Maun Lodge" desc="Comfortable stay close to Maun town with river access." />
          <HotelCard name="Crocodile Camp Safari & Spa" desc="Riverside retreat with safari tours and spa services." />
        </div>
      </section>

      <section className="bg-gray-100 p-6">
        <h2 className="text-2xl font-semibold mb-4">Popular Activities</h2>
        <ul className="list-disc list-inside">
          <li>Mokoro (dugout canoe) trips into the Delta</li>
          <li>Game drives and guided safaris</li>
          <li>Scenic flights over the Okavango Delta</li>
          <li>Birdwatching and nature walks</li>
          <li>Visit to local villages and cultural experiences</li>
        </ul>
      </section>

      <section className="p-6">
        <h2 className="text-2xl font-semibold mb-4">Travel Tips</h2>
        <ul className="list-disc list-inside">
          <li>Best time to visit: May to October (dry season)</li>
          <li>Fly into Maun Airport (MUB)</li>
          <li>Pack light, breathable clothes and sun protection</li>
          <li>Book safaris in advance during peak season</li>
        </ul>
      </section>

      <footer className="bg-green-900 text-white p-4 text-center">
        <p>&copy; 2025 Discover Maun. All rights reserved.</p>
      </footer>
    </div>
  );
}

function HotelCard({ name, desc }) {
  return (
    <div className="bg-white rounded-2xl shadow-md p-4">
      <h3 className="text-xl font-bold mb-2">{name}</h3>
      <p>{desc}</p>
      <button className="mt-4 bg-green-700 text-white px-4 py-2 rounded-xl">View More</button>
    </div>
  );
}
